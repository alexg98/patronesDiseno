package com.patrones.estructurales.Proxy;

public class Proxy {

}
