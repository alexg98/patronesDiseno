package com.patrones.otros;
/*
 * Patron contenedor
 */
public class InyeccionDedependencias {

}
