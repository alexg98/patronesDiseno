package com.patrones.comportamiento;

public class Creacionales {

}
